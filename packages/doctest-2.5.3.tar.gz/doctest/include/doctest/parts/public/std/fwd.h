#ifndef DOCTEST_PARTS_PUBLIC_STD_FWD
#define DOCTEST_PARTS_PUBLIC_STD_FWD

#include "doctest/parts/public/config.h"

DOCTEST_SUPPRESS_PUBLIC_WARNINGS_PUSH

#ifdef DOCTEST_CONFIG_USE_STD_HEADERS
#include <cstddef>
#include <ostream>
#include <istream>
#else // DOCTEST_CONFIG_USE_STD_HEADERS

DOCTEST_MSVC_SUPPRESS_WARNING_PUSH
DOCTEST_MSVC_SUPPRESS_WARNING(4643) // Forward declaring 'X' in namespace std is not permitted by the C++ Standard.
DOCTEST_MSVC_SUPPRESS_WARNING(5285) // Cannot declare a specialization for 'template name': template argument.

// NOLINTBEGIN(bugprone-std-namespace-modification, cert-dcl58-cpp)
namespace std {
typedef decltype(nullptr) nullptr_t;     // NOLINT(modernize-use-using)
typedef decltype(sizeof(void *)) size_t; // NOLINT(modernize-use-using)
template <class charT>
struct char_traits;
template <>
struct char_traits<char>;
template <class charT, class traits>
class basic_ostream;                                    // NOLINT(fuchsia-virtual-inheritance)
typedef basic_ostream<char, char_traits<char>> ostream; // NOLINT(modernize-use-using)
template <class traits>
// NOLINTNEXTLINE
basic_ostream<char, traits> &operator<<(basic_ostream<char, traits> &, const char *);
template <class charT, class traits>
class basic_istream;
typedef basic_istream<char, char_traits<char>> istream; // NOLINT(modernize-use-using)
template <class... Types>
DOCTEST_MSVC_SUPPRESS_WARNING_WITH_PUSH(5285) // Specializing template std::tuple is forbidden
class tuple;
DOCTEST_MSVC_SUPPRESS_WARNING_POP
#if DOCTEST_MSVC >= DOCTEST_COMPILER(19, 20, 0)
// see this issue on why this is needed: https://github.com/doctest/doctest/issues/183
template <class Ty>
class allocator;
template <class Elem, class Traits, class Alloc>
class basic_string;
using string = basic_string<char, char_traits<char>, allocator<char>>;
#endif // VS 2019
} // namespace std
// NOLINTEND(bugprone-std-namespace-modification, cert-dcl58-cpp)

DOCTEST_MSVC_SUPPRESS_WARNING_POP

#endif // DOCTEST_CONFIG_USE_STD_HEADERS

namespace doctest {
using std::size_t;
} // namespace doctest

DOCTEST_SUPPRESS_PUBLIC_WARNINGS_POP

#endif // DOCTEST_PARTS_PUBLIC_STD_FWD
