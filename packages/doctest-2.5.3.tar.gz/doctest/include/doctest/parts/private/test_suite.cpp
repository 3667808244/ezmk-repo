#include "doctest/parts/private/prelude.h"

DOCTEST_SUPPRESS_PRIVATE_WARNINGS_PUSH

#ifndef DOCTEST_CONFIG_DISABLE

namespace doctest {
namespace detail {

TestSuite &TestSuite::operator*(const char *in) noexcept {
    m_test_suite = in;
    return *this;
}

// sets the current test suite
int setTestSuite(const TestSuite &ts) noexcept {
    doctest_detail_test_suite_ns::getCurrentTestSuite() = ts;
    return 0;
}

} // namespace detail
} // namespace doctest

namespace doctest_detail_test_suite_ns {
// holds the current test suite
doctest::detail::TestSuite &getCurrentTestSuite() noexcept {
    static doctest::detail::TestSuite data{};
    return data;
}
} // namespace doctest_detail_test_suite_ns

#endif // DOCTEST_CONFIG_DISABLE

DOCTEST_SUPPRESS_PRIVATE_WARNINGS_POP
